﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using wpfsample.Common;
using wpfsample.Models;

namespace wpfsample.Viewmodels
{
    public class ProductViewmodel: ViewModelBase
    {

        #region Props

        #endregion

        #region Constructor

        public ProductViewmodel()
        {
           

        }
               

        #endregion

        #region Commands
   

        #endregion

        #region Methods

        #endregion
    }
}
