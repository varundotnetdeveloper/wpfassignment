﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using wpfsample.Common;
using wpfsample.Models;

namespace wpfsample.Viewmodels
{
    public class ProductsViewmodel: ViewModelBase
    {
        #region Properties
   
               
        public string TotalAmount
        {
            get
            {
               return GridListViewModel.Count > 0?
                    GridListViewModel.Sum(c => c.Amount).ToString(): 
                    string.Empty;
            }
           
        }

        private int _selectedSerialId;
        public int SelectedSerialId
        {
            get
            {
                return _selectedSerialId;
            }
            set { 

                _selectedSerialId = value;
                NotifyPropertyChanged("SelectedSerialId");

            }
        }
        private Product _selectedProduct;

        public Product SelectedProduct
        {
            get
            {
                return _selectedProduct;
            }
            set
            {

                _selectedProduct = value;
                NotifyPropertyChanged("SelectedProduct");

            }
        }

        private int _selectedGridSerialId;
        public int SelectedGridSerialId
        {
            get
            {
                return _selectedGridSerialId;
            }
            set
            {

                _selectedGridSerialId = value;
                NotifyPropertyChanged("SelectedGridSerialId");

            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
           set 
            { 
                _isBusy = value; 
                NotifyPropertyChanged("IsBusy"); 
            }
        }

        private ObservableCollection<Product> _gridListViewModel;
        public ObservableCollection<Product> GridListViewModel
        {
            get
            {
                return _gridListViewModel;
            }
            set
            {
                _gridListViewModel = value;
                NotifyPropertyChanged("GridListViewModel");
            }
        }

        public List<Product> ProductsModel { get; set; }

        #endregion

        #region Constructor

        public ProductsViewmodel()
        {
            AddProductCommand = new AsyncCommand(ExecuteAddAsync, CanExecuteAdd);
            DeleteProductCommand = new AsyncCommand(ExecuteDeleteAsync, CanExecuteDelete);

            CellChangedCommand = new AsyncCommand(ExecuteCellChangedAsync, CanExecuteCellChanged);
            GetData();
            SetupInitialData();

        }

        private void SetupInitialData()
        {
            //The assignment show first three records initially
            GridListViewModel = new ObservableCollection<Product> {
             new Product{ SerialNumber=1, ProductName= "Apple",CategoryName="Fruit", UnitRate=1,Quantity=4  },
                new Product{ SerialNumber=2, ProductName= "Shoe",CategoryName="Clothing",UnitRate=5,Quantity=22  },
                new Product{ SerialNumber=3, ProductName= "Orange",CategoryName="Fruit",UnitRate=2,Quantity=5 }
            };
        }

        private void GetData()
        {
            ProductsModel = new List<Product> {
                new Product{ SerialNumber=1, ProductName= "Apple",CategoryName="Fruit",   },
                new Product{ SerialNumber=2, ProductName= "Shoe",CategoryName="Clothing" },
                new Product{ SerialNumber=3, ProductName= "Orange",CategoryName="Fruit" },
                new Product{ SerialNumber=4, ProductName= "Belt",CategoryName="Clothing" },
                new Product{ SerialNumber=5, ProductName= "Tie",CategoryName="Clothing"  },
                new Product{ SerialNumber=6, ProductName= "Peach",CategoryName="Fruit" },
                new Product{ SerialNumber=7, ProductName= "Watch",CategoryName="Clothing" },
            };
        }

        #endregion

        #region Commands
        public IAsyncCommand AddProductCommand { get; private set; }
        public IAsyncCommand DeleteProductCommand { get; private set; }
        public IAsyncCommand CellChangedCommand { get; private set; }

        #endregion

        #region Methods

        private async Task ExecuteAddAsync()
        {
            try
            {
                IsBusy = true;
                if (GridListViewModel.Any(c => c.SerialNumber == SelectedSerialId))
                {
                    //Item exists dialog box saying its already there.
                    //Due to timecontraint dialogbox couldn't be added but the logic works the best

                }
                else
                {
                    //Add row to gridview
                    GridListViewModel.Add( ProductsModel.Where(x =>x.SerialNumber == SelectedSerialId).FirstOrDefault());
                }
               

            }
            finally
            {
                IsBusy = false;
            }
        }

        private bool CanExecuteAdd()
        {
            return !IsBusy;
        }
        private async Task ExecuteDeleteAsync()
        {
            try
            {
                IsBusy = true;
                GridListViewModel.Remove(SelectedProduct);
            }
            finally
            {
                IsBusy = false;
            }
        }

        private bool CanExecuteDelete()
        {
            //return SelectedProduct != null;
            return true;
        }

        private async Task ExecuteCellChangedAsync()
        {
            try
            {
                //Change the total amount to reflect everytime there is change in cell changed value
                //We get value from only editable cells
                
                NotifyPropertyChanged("TotalAmount");



            }
            finally
            {
                IsBusy = false;
            }
        }

        private bool CanExecuteCellChanged()
        {
            return !IsBusy;
        }
        #endregion
    }
}
